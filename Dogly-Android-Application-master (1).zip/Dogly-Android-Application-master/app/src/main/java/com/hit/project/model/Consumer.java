package com.hit.project.model;

public interface Consumer <T> {
    public void apply(T param);
}
