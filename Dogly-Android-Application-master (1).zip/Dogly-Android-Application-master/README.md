#### Dogly - Dog Adoption
An Android application which connects between people who want to adopt a dog and people 
who want to hand over a dog for adoption.

Tech: MVVM, Material Design, Serverless (Firebase cloud).
